-- Schema additions for NewsPulse Nifty (v2). Run AFTER sql/schema.sql. Idempotent.
-- Primary keys on dimensions only; fact key uniqueness is checked by tests.

-- ---------- New / extended dimensions ----------
CREATE TABLE IF NOT EXISTS dim_sector (
  sector_key INTEGER PRIMARY KEY,
  sector_name VARCHAR UNIQUE            -- Financial Services, IT, Automobile, Pharma, Energy, FMCG, Metals, Infrastructure, Telecom, Consumer
);

CREATE TABLE IF NOT EXISTS dim_stock (
  stock_key INTEGER PRIMARY KEY,
  symbol VARCHAR UNIQUE,
  company_name VARCHAR,
  sector_key INTEGER,
  isin VARCHAR,
  in_nifty50 BOOLEAN,
  first_trade_date DATE, last_trade_date DATE,
  sector_source VARCHAR                 -- 'meta' | 'config' | 'unknown'
);

CREATE TABLE IF NOT EXISTS dim_stock_alias (
  stock_key INTEGER, alias VARCHAR,
  alias_type VARCHAR,                   -- name | short | ticker
  case_sensitive BOOLEAN,
  needs_context BOOLEAN
);

CREATE TABLE IF NOT EXISTS dim_event (
  event_key INTEGER PRIMARY KEY,
  event_label VARCHAR,
  event_type VARCHAR,                   -- policy | shock | election | budget | global | crisis
  start_date DATE, end_date DATE,
  sector_key INTEGER                    -- NULL = market-wide
);

CREATE TABLE IF NOT EXISTS dim_trading_calendar (
  date_key INTEGER PRIMARY KEY,         -- every calendar date in the window
  is_trading_day BOOLEAN,
  effective_trading_date_key INTEGER    -- same day if trading, else next trading day (NULL after last trading day)
);

-- ---------- Existing table extensions ----------
ALTER TABLE fact_headline ADD COLUMN IF NOT EXISTS is_market_report BOOLEAN;   -- reports the market move itself
ALTER TABLE fact_headline ADD COLUMN IF NOT EXISTS effective_trading_date_key INTEGER;

-- ---------- New facts ----------
-- Grain: one stock per trading day
CREATE TABLE IF NOT EXISTS fact_stock_daily (
  date_key INTEGER, stock_key INTEGER, dataset_key INTEGER,
  open DOUBLE, high DOUBLE, low DOUBLE, close DOUBLE, volume DOUBLE, turnover DOUBLE,
  daily_return DOUBLE,          -- close / prev_close - 1
  abs_return DOUBLE,
  range_pct DOUBLE,             -- (high - low) / prev_close
  vol_20d DOUBLE,               -- stddev of last 20 daily returns
  return_5d DOUBLE,
  is_outlier BOOLEAN,           -- |daily_return| > 0.25 (likely split/bonus)
  next_day_return DOUBLE,       -- target source, for modelling only
  next_day_up BOOLEAN
);

-- Grain: one headline x one stock
CREATE TABLE IF NOT EXISTS fact_news_stock_mention (
  headline_key BIGINT, stock_key INTEGER, date_key INTEGER, effective_trading_date_key INTEGER,
  matched_alias VARCHAR,
  match_method VARCHAR,         -- exact | ticker | context
  is_ambiguous_alias BOOLEAN,
  is_market_report BOOLEAN
);

-- Grain: one sector per calendar date (news side)
CREATE TABLE IF NOT EXISTS fact_news_sector_daily (
  date_key INTEGER, effective_trading_date_key INTEGER, sector_key INTEGER,
  news_count BIGINT,
  news_count_non_market BIGINT,      -- excludes market-report headlines
  sum_sentiment DOUBLE,
  high_sensational_count BIGINT,
  source VARCHAR                     -- 'mention' | 'keyword' | 'both'
);

-- ---------- Cubes (sums and counts only) ----------
CREATE TABLE IF NOT EXISTS cube_sector_month (
  year SMALLINT, month TINYINT, sector_key INTEGER,
  news_count BIGINT, news_count_non_market BIGINT,
  sum_sentiment DOUBLE, high_sensational_count BIGINT,
  trading_days INTEGER, sum_return DOUBLE, sum_abs_return DOUBLE, stock_obs BIGINT
);

-- ---------- Mining outputs ----------
CREATE TABLE IF NOT EXISTS mining_event_study (
  event_key INTEGER, stock_key INTEGER, sector_key INTEGER,
  alpha DOUBLE, beta DOUBLE, est_days INTEGER,
  car_0_1 DOUBLE, car_0_5 DOUBLE, car_m1_5 DOUBLE,
  valid BOOLEAN, reason VARCHAR
);

CREATE TABLE IF NOT EXISTS mining_stock_clusters (
  stock_key INTEGER, cluster_id SMALLINT,
  ann_volatility DOUBLE, mean_daily_return DOUBLE, beta DOUBLE, max_drawdown DOUBLE,
  mentions_per_1000_days DOUBLE, mention_sentiment DOUBLE, news_sensitivity DOUBLE,
  pc1 DOUBLE, pc2 DOUBLE
);

CREATE TABLE IF NOT EXISTS mining_market_rules (
  rule_id INTEGER, antecedents VARCHAR, consequents VARCHAR,
  support DOUBLE, confidence DOUBLE, lift DOUBLE, support_count INTEGER
);

CREATE TABLE IF NOT EXISTS mining_direction_results (
  model VARCHAR, split VARCHAR, n INTEGER,
  accuracy DOUBLE, balanced_accuracy DOUBLE, f1 DOUBLE,
  baseline_majority DOUBLE, baseline_yesterday DOUBLE, binom_p_vs_baseline DOUBLE,
  notes VARCHAR
);

CREATE TABLE IF NOT EXISTS mining_surprise_days (
  date_key INTEGER, sector_key INTEGER,
  news_heat_z DOUBLE, abs_return_z DOUBLE, avg_return DOUBLE,
  kind VARCHAR                       -- news_driven | quiet_news_move
);

CREATE TABLE IF NOT EXISTS mining_mention_audit (
  headline_key BIGINT, stock_key INTEGER, matched_alias VARCHAR, headline_text VARCHAR,
  is_correct BOOLEAN                 -- filled by hand after reviewing the audit CSV
);
