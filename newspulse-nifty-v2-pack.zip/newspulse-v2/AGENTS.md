# AGENTS.md (v2): rules for coding agents (OpenCode)

Read this file fully before every task. Then read ONLY `BLUEPRINT_V2.md` (once per session) and the doc for the current phase.

## Project
NewsPulse Nifty: a Data Warehousing and Mining decision-support system. It combines Indian news headlines (Times of India), labelled statements (IFND), Nifty 50 index prices and per-stock Nifty 50 prices in a DuckDB fact-constellation warehouse, runs OLAP and mining operations, serves them through FastAPI, and presents them in a multipage Streamlit dashboard. This is an upgrade of the existing `dwm-india-news` v1 code. **Extend it. Do not rewrite working v1 code.**

## Stack
Python 3.11+, DuckDB, pandas, numpy, scikit-learn, mlxtend, scipy, statsmodels (event study regression), vaderSentiment, PyYAML, Typer, FastAPI, uvicorn, requests, Streamlit, plotly, joblib, pytest. Environment: Windows. Use `pathlib`, no Makefile, run everything as `python -m dwm <command>`.

## Layout (v1 plus v2 additions)
```
src/dwm/
  cli.py config.py db.py
  ingest/      toi.py ifnd.py nifty.py stocks.py meta.py            # v2: stocks.py, meta.py
  etl/         clean.py dates.py topics.py window.py audit.py calendar.py
  features/    text_features.py sentiment.py sensational.py keywords.py market_report.py
  linking/     aliases.py mentions.py sector_news.py audit_sample.py  # v2
  warehouse/   build_dims.py load_facts.py cubes.py stock_facts.py
  olap/        slice.py dice.py rollup.py drilldown.py pivot.py cube.py drill_across.py sector_ops.py
  mining/      trends.py bursts.py clustering.py apriori.py classifier.py cross_dataset.py
               event_study.py stock_clusters.py market_rules.py direction_model.py surprise_days.py  # v2
  inference/   facts.py templates.py report.py insights.py             # insights.py is v2
  api/         main.py routers/ (olap.py mining.py stocks.py events.py check.py insights.py brief.py)
  inference/   (v2 adds) brief.py
dashboard/
  Home.py                       # landing page + Quick Brief search
  ui.py                         # shared helpers (provided)
  pages/ 1_Market_Mood.py 2_Stock_Explorer.py 3_Sector_Cube.py 4_Event_Study.py
         5_Mining_Lab.py 6_Headline_Checker.py 7_Data_and_Schema.py 8_Insights.py
.streamlit/config.toml          # theme (provided)
sql/schema.sql  sql/schema_v2.sql  sql/olap_cookbook.sql
config/  datasets.yaml datasets_v2.yaml topic_map.yaml events.yaml events_v2.yaml stocks.yaml
         stock_aliases.yaml sector_keywords.yaml lexicons/
models/  *.joblib (gitignored)
tests/   (+ tests/fixtures/, TEST ONLY)
reports/ data/raw/ warehouse/
```

## Commands that must exist (v1 commands keep working)
```
python -m dwm ingest --dataset toi|ifnd|nifty|stocks|meta|all [--sample N]
python -m dwm etl [--years 5]
python -m dwm features [--chunk 100000]
python -m dwm link                   # v2: news<->stock/sector linking + audit sample
python -m dwm load
python -m dwm olap <operation> [options]
python -m dwm mine <trends|bursts|clusters|rules|classifier|cross|events|stockclusters|marketrules|direction|surprise|all>
python -m dwm infer
python -m dwm serve                  # FastAPI :8000
python -m dwm dashboard              # streamlit run dashboard/Home.py
python -m dwm usability              # SUS and task summary from reports/usability_results.csv
python -m dwm all --sample 50000
pytest
```

## Hard rules (v1 rules 1 to 12 still apply, restated)
1. **Never fabricate data.** No invented headlines, labels, prices, tickers or mentions. Only `tests/fixtures/` may contain fake rows, clearly marked; they never reach reports or the dashboard.
2. **Every number shown to users comes from a query or a computed model result.** No hard-coded statistics.
3. **Wording:** "risk-signal rate", never "fake news rate" for unlabelled headlines. "coincides with" for events, "associated with" for correlations, never "caused" or "predicts" unless a held-out test shows predictive skill over the baseline.
4. **Window computed from data** (`max(date)` of toi). Never hard-code years.
5. **No raw data, DuckDB file, models, secrets, `.env` in git.**
6. **Chunked reads** for big files. Aggregate in DuckDB SQL, not pandas loops.
7. **Idempotent** commands. **Deterministic**: `SEED = 42`.
8. **Windows safe:** multiprocessing only under main guards; `pathlib`; `encoding="utf-8"`.
9. **Scope discipline:** implement only the current phase. Report cross-phase issues instead of fixing them.
10. Every command supports `--sample N`.

### New v2 rules
11. **No look-ahead / leakage.** Features for day t use only data available at the end of day t; target is day t+1. Train/validation/test splits are chronological (never shuffled). Hyperparameters are tuned on validation only; report on test only. Always report the majority-class baseline and the "yesterday's direction" baseline.
12. **Trading calendar.** Join news to prices via `dim_trading_calendar.effective_trading_date_key`, never raw calendar date.
13. **Reverse-causality guard.** Predictive analysis excludes headlines with `is_market_report = TRUE`. Dashboards offer a toggle for descriptive views.
14. **Outliers.** Daily returns with absolute value > 25% are flagged `is_outlier = TRUE` and excluded from statistics and models (kept in tables).
15. **Ambiguous stock aliases need context** (see `config/stock_aliases.yaml`). Produce `reports/mention_audit_sample.csv` (200 stratified matches with an empty `is_correct` column for manual labelling) and a script that computes precision from it when filled.
16. **Cubes store sums and counts, never averages.** Derive ratios at query time.
17. **Front end talks to the API only** (`dashboard/ui.py: api_get`). No SQL, no pandas analytics, no model code in dashboard files.
18. **Every dashboard page must have:** `page_setup(...)`, a `question_box(question, decision)`, at least one chart with title, axis labels and a data-generated caption (`insight(...)`), a `how_computed(concept, explanation, sql)` panel, and `footer()`.
19. **Design rules:** use the theme in `.streamlit/config.toml`; consistent colour meaning (teal = news, amber = price/market, red/green only for down/up returns); no more than two chart types per page unless needed; loading states via cached calls; clear empty states ("Run `python -m dwm mine events` first").
20. **Disclaimer text** (educational, not investment advice, associations not causes, style not truth) must appear on every page via `footer()`.
21. **Performance:** dashboards query cubes and mining tables, not raw facts, for anything over 100k rows. Paginate headline lists (max 50 rows).

## Definition of done (every phase)
- Code in the listed modules, type hints, short docstrings.
- Phase tests `pytest tests/test_<phase>_*.py` pass; all earlier tests still pass.
- The phase CLI command runs on `--sample 50000` without error.
- Summary: files changed, commands run, test results, anything not done.

## Task workflow
1. Read AGENTS.md, then the phase doc.
2. Write or update tests first when practical.
3. Implement.
4. Run phase tests, then the full suite.
5. Run the phase command on the dev sample.
6. Report the summary and stop. Do not start the next phase.
