"""Shared UI helpers for the NewsPulse Nifty dashboard.

Rules (see AGENTS.md): pages call page_setup() first, show a question_box(), at least one
chart with an insight() caption, a how_computed() panel, and footer(). The dashboard only
talks to the FastAPI backend through api_get / api_post. No SQL or analytics here.
"""
from __future__ import annotations

import os
from typing import Any

import pandas as pd
import requests
import streamlit as st

API_URL = os.getenv("DWM_API_URL", "http://127.0.0.1:8000")

DISCLAIMER = (
    "Educational project, not investment advice. Patterns shown are associations in "
    "historical data, not causes. Headline signals measure writing style, not truth."
)

# Colour meaning (keep consistent on every page)
NEWS_COLOR = "#14B8A6"    # teal   = news
PRICE_COLOR = "#F59E0B"   # amber  = price / market
UP_COLOR = "#22C55E"
DOWN_COLOR = "#EF4444"

_CSS = """
<style>
.np-card {border:1px solid rgba(148,163,184,.25); border-radius:12px; padding:.8rem 1rem;
          background:rgba(20,184,166,.07); margin-bottom:.8rem; font-size:.95rem;}
.np-tag  {display:inline-block; padding:.1rem .55rem; border-radius:999px; font-size:.75rem;
          background:rgba(245,158,11,.18); border:1px solid rgba(245,158,11,.5); margin-right:.3rem;}
[data-testid="stMetricValue"] {font-size:1.6rem;}
</style>
"""


def page_setup(title: str, icon: str = "📈", concept: str | None = None) -> None:
    """Must be the first Streamlit call on a page."""
    st.set_page_config(page_title=f"{title} | NewsPulse Nifty", page_icon=icon, layout="wide")
    st.markdown(_CSS, unsafe_allow_html=True)
    st.title(f"{icon} {title}")
    if concept:
        st.markdown(f'<span class="np-tag">DWM concept: {concept}</span>', unsafe_allow_html=True)


def question_box(question: str, decision: str) -> None:
    st.markdown(
        f'<div class="np-card"><b>Question this answers:</b> {question}<br>'
        f"<b>Decision it supports:</b> {decision}</div>",
        unsafe_allow_html=True,
    )


def how_computed(concept: str, explanation: str, sql: str | None = None) -> None:
    with st.expander(f"How this was computed: {concept}"):
        st.write(explanation)
        if sql:
            st.code(sql, language="sql")


def insight(text: str) -> None:
    """One data-generated sentence under a chart. Never hand-typed numbers."""
    st.info(text)


def kpi_row(items: list[tuple[str, str, str | None]]) -> None:
    cols = st.columns(len(items))
    for col, (label, value, delta) in zip(cols, items):
        col.metric(label, value, delta)


def empty_state(command: str) -> None:
    st.warning(f"No results yet. Run `{command}` first, then refresh this page.")


def footer() -> None:
    st.divider()
    st.caption(DISCLAIMER)


@st.cache_data(ttl=600, show_spinner="Asking the warehouse...")
def api_get(path: str, **params: Any) -> Any:
    """GET from the backend. Returns parsed JSON, or None if the backend says 404."""
    clean = {k: v for k, v in params.items() if v is not None}
    resp = requests.get(f"{API_URL}{path}", params=clean, timeout=60)
    if resp.status_code == 404:
        return None
    resp.raise_for_status()
    return resp.json()


def api_post(path: str, payload: dict[str, Any]) -> Any:
    resp = requests.post(f"{API_URL}{path}", json=payload, timeout=60)
    resp.raise_for_status()
    return resp.json()


def to_df(data: Any) -> pd.DataFrame:
    return pd.DataFrame(data) if data else pd.DataFrame()
